
/** 获取时间 **/
function getNowUtcTime() {
	var date = new Date();
	var nowYear   = date.getFullYear();
	var nowMoth   = date.getMonth() + 1;
	var nowDay    = date.getDate();
	var nowHour   = date.getHours();
	var nowMinute = date.getMinutes();
	var nowSecond = date.getSeconds();

	// console.log(Date.UTC(nowYear, nowMoth, nowDay, nowHour,nowMinute + 10,nowSecond));
	var expired = Date.UTC(nowYear, nowMoth, nowDay, nowHour,nowMinute + 10,nowSecond) + '';
	// console.log(Number(expired.substr(0,10)));
	return Number(expired.substr(0,10));
}

function restFulSha(RequestMethod, url, topbabysecret) {

	var expired   = getNowUtcTime();
	var url       = RequestMethod + "\n" + url + "\n" + expired + "\n";
	var signature = $.base64('encode', CryptoJS.HmacSHA1(url, topbabysecret));
	var obj       = {
		expires: expired,
		signature: signature
	}
	return obj;
}
